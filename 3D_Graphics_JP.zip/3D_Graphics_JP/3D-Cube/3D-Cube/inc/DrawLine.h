// Course: CMPE - 240
// Submitted by: Harshil B Darji
// SID: 1641035

#ifndef DRAWLINE_H_
#define DRAWLINE_H_

void drawline(int16_t x0, int16_t y0, int16_t x1, int16_t y1, uint32_t color);
void drawPixel(int16_t x, int16_t y, uint32_t color);

#endif /* DRAWLINE_H_ */
